import "./style.css";

// Import the the `arcgis-layer-list`, `arcgis-map` and `arcgis-zoom` components
// from the `@arcgis/map-components` package.
import "@arcgis/map-components/components/arcgis-layer-list";
import "@arcgis/map-components/components/arcgis-map";
import "@arcgis/map-components/components/arcgis-zoom";

// Import the `calcite-navigation`, `calcite-navigation-logo`, and `calcite-shell` components
// from the `@esri/calcite-components` package.
import "@esri/calcite-components/components/calcite-navigation";
import "@esri/calcite-components/components/calcite-navigation-logo";
import "@esri/calcite-components/components/calcite-shell";

// Get a reference to the arcgis-layer-list element.
const arcgisLayerList = document.querySelector("arcgis-layer-list");

// Set the listItemCreatedFunction to add a legend to each list item.
arcgisLayerList.listItemCreatedFunction = (event) => {
  const { item } = event;
  if (item.layer.type !== "group") {
    item.panel = {
      content: "legend",
    };
  }
};

// Get a reference to the arcgis-map element.
const viewElement = document.querySelector("arcgis-map");

// Since we are using property values from the map component,
// we use the arcgisViewReadyChange event to determine when the map is ready.
viewElement.addEventListener("arcgisViewReadyChange", () => {
  const { portalItem } = viewElement.map;

  // Get a reference to the calcite-navigation-logo element.
  const navigationLogo = document.querySelector("calcite-navigation-logo");

  // Set the navigationLogo's properties to the portalItem's title, snippet, and thumbnailUrl.
  navigationLogo.heading = portalItem.title;
  navigationLogo.description = portalItem.snippet;
  navigationLogo.thumbnail = portalItem.thumbnailUrl;

  // Find the accidental deaths layer in the `event.target.map.layers` collection.
  // https://developers.arcgis.com/javascript/latest/references/core/Map/#layers
  const layer = viewElement.map.layers.find((layer) => layer.id === "Accidental_Deaths_8938");

  //  Modify the layer's popup template title.
  //  https://developers.arcgis.com/javascript/latest/references/core/PopupTemplate/
  layer.popupTemplate.title = "Accidental Deaths";
});
