<script setup>
import Map from "./components/Map.vue";
</script>

<template>
  <Map />
</template>
