export const HTMLClasses = {
  Show: "show",
  Hide: "hide",
  NotifyPanel: "notifyPanel",
  DisableInteractions: "disable-interactions",
  Chart: "chart",
} as const;
