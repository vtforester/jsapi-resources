/// <reference types="@arcgis/map-components/types/react" />
/// <reference types="@arcgis/charts-components/types/react" />
/// <reference types="@esri/calcite-components/types/react" />
